import React from "react";

const WeSkiLogo: React.FC = () => {
    return (
        <img width={130} height={26} src="https://res.cloudinary.com/ht4mr7djk/image/upload/v1727341362/weski_logo_horiznotal.svg" />
    )
}

export default WeSkiLogo;