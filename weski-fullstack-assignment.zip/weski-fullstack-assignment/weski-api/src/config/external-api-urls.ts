export const externalApiUrls = [
  'https://gya7b1xubh.execute-api.eu-west-2.amazonaws.com/default/HotelsSimulator',
];